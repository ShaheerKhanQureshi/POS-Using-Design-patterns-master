/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos;

/**
 *
 * @author Abdul Moiz Chishti
 */
public abstract class A {
   abstract void insert();
   abstract void update();
   abstract void delete();
   abstract void search();

   //template method 
   }