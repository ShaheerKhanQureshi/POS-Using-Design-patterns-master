/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos;

/**
 *
 * @author Abdul Moiz Chishti
 */
class posale implements dash_interface { 
        public void load() { 
 	 	pos sp = new pos();
                sp.setVisible(true);            
 	}       
}  

